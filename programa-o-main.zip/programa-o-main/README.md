# Trabalho de Programação
# Sobre
Este é um site teste da diciplina de Matemática II- PROGRAMAÇÃO, buscando promover maior acessibiliade na web 
## Recursos de Acessibiliade
- Atributo aria
- alt
- tab-index
- menu de acesibilidade
## Tecnologias utilizada
- HTML
- CSS
- JS